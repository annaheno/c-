﻿namespace SqlTest2
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button3 = new System.Windows.Forms.Button();
            this.btnCsv2DataTable = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSQLEnv = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbServer = new System.Windows.Forms.TextBox();
            this.tbDB = new System.Windows.Forms.TextBox();
            this.tbTable = new System.Windows.Forms.TextBox();
            this.tbID = new System.Windows.Forms.TextBox();
            this.tbPasswd = new System.Windows.Forms.TextBox();
            this.btnToDataTable = new System.Windows.Forms.Button();
            this.btnToSQLDB = new System.Windows.Forms.Button();
            this.btn_import = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbCoaming = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbSQLRows = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(201, 140);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(191, 38);
            this.button3.TabIndex = 41;
            this.button3.Text = "⑤ DataTable Clear";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnCsv2DataTable
            // 
            this.btnCsv2DataTable.Font = new System.Drawing.Font("굴림", 11F);
            this.btnCsv2DataTable.Location = new System.Drawing.Point(19, 140);
            this.btnCsv2DataTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnCsv2DataTable.Name = "btnCsv2DataTable";
            this.btnCsv2DataTable.Size = new System.Drawing.Size(172, 38);
            this.btnCsv2DataTable.TabIndex = 40;
            this.btnCsv2DataTable.Text = "① Excel-> DataTable";
            this.btnCsv2DataTable.UseVisualStyleBackColor = true;
            this.btnCsv2DataTable.Click += new System.EventHandler(this.btnCsv2DataTable_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.btnSQLEnv);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.tbServer);
            this.groupBox2.Controls.Add(this.tbDB);
            this.groupBox2.Controls.Add(this.tbTable);
            this.groupBox2.Controls.Add(this.tbID);
            this.groupBox2.Controls.Add(this.tbPasswd);
            this.groupBox2.Location = new System.Drawing.Point(397, 19);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(442, 128);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "SQL DB 설정";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 12);
            this.label6.TabIndex = 30;
            this.label6.Text = "SQL환경불러오기";
            // 
            // btnSQLEnv
            // 
            this.btnSQLEnv.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSQLEnv.BackgroundImage")));
            this.btnSQLEnv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSQLEnv.Location = new System.Drawing.Point(29, 18);
            this.btnSQLEnv.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSQLEnv.Name = "btnSQLEnv";
            this.btnSQLEnv.Size = new System.Drawing.Size(84, 66);
            this.btnSQLEnv.TabIndex = 29;
            this.btnSQLEnv.UseVisualStyleBackColor = true;
            this.btnSQLEnv.Click += new System.EventHandler(this.btnSQLEnv_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(165, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 12;
            this.label1.Text = "서버이름";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(331, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(297, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "Passwd";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(137, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 12);
            this.label2.TabIndex = 12;
            this.label2.Text = "Database이름";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(161, 63);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 12);
            this.label5.TabIndex = 12;
            this.label5.Text = "Table이름";
            // 
            // tbServer
            // 
            this.tbServer.Location = new System.Drawing.Point(229, 18);
            this.tbServer.Name = "tbServer";
            this.tbServer.ReadOnly = true;
            this.tbServer.Size = new System.Drawing.Size(201, 21);
            this.tbServer.TabIndex = 14;
            // 
            // tbDB
            // 
            this.tbDB.Location = new System.Drawing.Point(229, 39);
            this.tbDB.Name = "tbDB";
            this.tbDB.ReadOnly = true;
            this.tbDB.Size = new System.Drawing.Size(201, 21);
            this.tbDB.TabIndex = 15;
            // 
            // tbTable
            // 
            this.tbTable.Location = new System.Drawing.Point(229, 61);
            this.tbTable.Name = "tbTable";
            this.tbTable.Size = new System.Drawing.Size(201, 21);
            this.tbTable.TabIndex = 16;
            this.tbTable.Text = "TB_PROJ_TEST";
            // 
            // tbID
            // 
            this.tbID.Location = new System.Drawing.Point(354, 83);
            this.tbID.Name = "tbID";
            this.tbID.ReadOnly = true;
            this.tbID.Size = new System.Drawing.Size(77, 21);
            this.tbID.TabIndex = 17;
            // 
            // tbPasswd
            // 
            this.tbPasswd.Location = new System.Drawing.Point(354, 106);
            this.tbPasswd.Name = "tbPasswd";
            this.tbPasswd.ReadOnly = true;
            this.tbPasswd.Size = new System.Drawing.Size(77, 21);
            this.tbPasswd.TabIndex = 18;
            this.tbPasswd.UseSystemPasswordChar = true;
            // 
            // btnToDataTable
            // 
            this.btnToDataTable.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnToDataTable.Location = new System.Drawing.Point(135, 60);
            this.btnToDataTable.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnToDataTable.Name = "btnToDataTable";
            this.btnToDataTable.Size = new System.Drawing.Size(97, 35);
            this.btnToDataTable.TabIndex = 38;
            this.btnToDataTable.Text = "⑥ <--";
            this.btnToDataTable.UseVisualStyleBackColor = true;
            // 
            // btnToSQLDB
            // 
            this.btnToSQLDB.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnToSQLDB.Location = new System.Drawing.Point(135, 24);
            this.btnToSQLDB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnToSQLDB.Name = "btnToSQLDB";
            this.btnToSQLDB.Size = new System.Drawing.Size(97, 34);
            this.btnToSQLDB.TabIndex = 37;
            this.btnToSQLDB.Text = "③ -->";
            this.btnToSQLDB.UseVisualStyleBackColor = true;
            this.btnToSQLDB.Click += new System.EventHandler(this.btnToSQLDB_Click);
            // 
            // btn_import
            // 
            this.btn_import.BackColor = System.Drawing.Color.White;
            this.btn_import.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_import.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_import.Font = new System.Drawing.Font("굴림", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_import.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.btn_import.Location = new System.Drawing.Point(18, 17);
            this.btn_import.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
            this.btn_import.Name = "btn_import";
            this.btn_import.Size = new System.Drawing.Size(95, 83);
            this.btn_import.TabIndex = 33;
            this.btn_import.Text = "Data Table";
            this.btn_import.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(249, 16);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(88, 84);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 184);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(830, 359);
            this.tabControl1.TabIndex = 34;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LemonChiffon;
            this.tabPage1.Controls.Add(this.lbCoaming);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(822, 333);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "② DataTable";
            // 
            // lbCoaming
            // 
            this.lbCoaming.AutoSize = true;
            this.lbCoaming.Location = new System.Drawing.Point(13, 313);
            this.lbCoaming.Name = "lbCoaming";
            this.lbCoaming.Size = new System.Drawing.Size(91, 12);
            this.lbCoaming.TabIndex = 12;
            this.lbCoaming.Text = "Coaming Q\'ty :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 13);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 27;
            this.dataGridView1.Size = new System.Drawing.Size(802, 289);
            this.dataGridView1.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightCyan;
            this.tabPage2.Controls.Add(this.lbSQLRows);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(822, 333);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "④ SQL DB Data";
            // 
            // lbSQLRows
            // 
            this.lbSQLRows.AutoSize = true;
            this.lbSQLRows.Location = new System.Drawing.Point(10, 309);
            this.lbSQLRows.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbSQLRows.Name = "lbSQLRows";
            this.lbSQLRows.Size = new System.Drawing.Size(45, 12);
            this.lbSQLRows.TabIndex = 14;
            this.lbSQLRows.Text = "Rows :";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 14);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowTemplate.Height = 27;
            this.dataGridView2.Size = new System.Drawing.Size(802, 289);
            this.dataGridView2.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(751, 165);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 43;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(624, 167);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 42;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(858, 557);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnCsv2DataTable);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnToDataTable);
            this.Controls.Add(this.btnToSQLDB);
            this.Controls.Add(this.btn_import);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnCsv2DataTable;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSQLEnv;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbServer;
        private System.Windows.Forms.TextBox tbDB;
        private System.Windows.Forms.TextBox tbTable;
        private System.Windows.Forms.TextBox tbID;
        private System.Windows.Forms.TextBox tbPasswd;
        private System.Windows.Forms.Button btnToDataTable;
        private System.Windows.Forms.Button btnToSQLDB;
        private System.Windows.Forms.Button btn_import;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lbCoaming;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lbSQLRows;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

