﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace SqlTest2
{
    public partial class DataBase
    {
        // mssql 이랑 연결
        string ConnectionString =
            "DESKTOP-VSUO7QQ\\SQLEXPRESS"
        + "database=master;"
        + "uid=sa;"
        + "pwd=1234;";

        SqlConnection conn = new SqlConnection();
    }

    //public DataBase()
    //{
    //    string line = "";
    //    string serverNm = "";
    //    string dbase = "";
    //    string user = "";
    //    string pass = "";

    //    try
    //    {
    //        StreamReader file = new StreamReader(Environment.CurrentDirectory + @"\Conf\SQLDB.ini");
    //        while ((line = file.ReadLine()) != null)
    //        {
    //            if (line.Contains("SERVER["))
    //            {
    //                serverNm = line.Split('[')[1].Split(']')[0];
    //            }
    //            else if (line.Contains("DATABASE["))
    //            {
    //                dbase = line.Split('[')[1].Split(']')[0];
    //            }
    //            else if (line.Contains("USER["))
    //            {
    //                user = line.Split('[')[1].Split(']')[0];
    //            }
    //            else if (line.Contains("PASSWD["))
    //            {
    //                pass = line.Split('[')[1].Split(']')[0];
    //            }

    //        }
    //        file.Close();
    //        ConnectionString = string.Format(@"Server={0};database={1};uid={2};pwd={3};", serverNm, dbase, user, pass);
    //    }
    //    catch { }
    //}
}
