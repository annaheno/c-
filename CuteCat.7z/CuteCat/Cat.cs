﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CuteCat
{
    public class Cat
    {
        public string Name;
        public int Age;

        private int Happiness; // 행복지수

        public Cat(string name, int age) // 생성자는 무조건 public
        {
            this.Name = name;
            this.Age = age;

        }

        public void GetBored()
        {
            Happiness = Happiness - 10;

            if (Happiness < 0)
                Happiness = 0; // 아무리 행복지수가 떨어져도 0 이하가 될 수 없게끔
        }

        public void Play()
        {
            // this.Name = name; (this : 그 클래스의 현재 인스턴스
            Happiness = Happiness + 10;

            if (Happiness > 100)
                Happiness = 100;
        }

        public void Eat()
        {
            Happiness = Happiness + 20;

            if (Happiness > 100)
                Happiness = 100;
        }

        public string Express()
        {
            string message = "";

            if (Happiness >= 80)
                message = "I'm very happy.";
            else if (Happiness >= 60)
                message = "I'm happy";
            else if (Happiness >= 40)
                message = "I'm so so";
            else if (Happiness >= 20)
                message = "I'm gloomy";
            else
                message = "I'm sad";
            return this.Name + ": " + message;
        }
    }
}
